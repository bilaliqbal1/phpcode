<?php
include "Work/java.php";
$obj=new functions();
$obj->conn();
	if(isset($_POST['btn']))
	{
		$obj->adddata($_POST['id'],$_POST['name'],$_POST['email'],$_POST['pass']);
	}

?>

<html>
	<center>
		<h1>Registration Form</h1>
			<table border="2">
				<form method="POST">
					<tr>
						<th>id</th>
							<td><input type="number" name="id"/></td>
					</tr>
					
						<tr>
						<th>Name</th>
							<td><input type="text" name="name"/></td>
					</tr>
					
						<tr>
						<th>Email</th>
							<td><input type="email" name="email"/></td>
					</tr>
					
						<tr>
						<th>Password</th>
							<td><input type="password" name="pass"/></td>
					</tr>
					
						<tr>
						<th> : </th>
							<td><input type="submit" name="btn" value="Submit"/></td>
					</tr>
			</form>			
		</table>
		
		<h1>Student Information</h1>
		<table border="1">
			<tr>
				<th> Sno </th>
				<th> Name </th>
				<th> Email </th>
				<th> Password </th>
			</tr
			
			<?php $obj->showdata();?>
		</table>
</html>

