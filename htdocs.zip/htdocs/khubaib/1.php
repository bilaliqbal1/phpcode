<html>
<body>
<form method="post">
   <input type="text" name="txt_name" placeholder="Enter your name"/></br>
   <input type="email" name="txt_email" placeholder="Enter your E-mail"/></br>
   <input type="password" name="txt_pass1" placeholder="Enter your Password"/></br>
   <input type="password" name="txt_pass2" placeholder="Confirm your Password"/></br>
   <input type="submit" name="btn_click" value="click me"/></br>
</form>
</center>
</body>
</html>
<?php
 if(isset($_post['btn_click']))
	 $name=$_POST['txt_name'];
     $email=$_POST['txt_email'];
     $pass=$_POST['txt_pass1'];
	 $Cpass=$_POST['txt_pass2'];
	 
	 if($email == $email)
	 {
		 if($pass == "$pass" && $Cpass == $pass){
			 echo "<script>alert('Login succesfully')</script>" ;	 
		 }
		 else
		 {
		 echo "<script>alert('Password didn't match')</script>" ;
	 
		 }
		 	 echo "<script>alert('Login Successfully')</script>" ;
		 }
	 else 
	 {
		 echo "<script>alert('Invalid E-mail')</script>" ; 
	 }
?>