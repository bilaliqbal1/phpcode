<html>
     <center>
    <form method="post">
	   <table border="2">
	        <tr>
			    <th>Name</th>
				 <td><input type="text" name="txtname"></td>
			</tr>
			
			<tr>
			    <th>Father-Name</th>
				 <td><input type="text" name="txtfname"></td>
			</tr>
			
			<tr>
			    <th>Roll-No</th>
				 <td><input type="text" name="txtroll"></td>
			</tr>
			<tr>
			    <th>Physics</th>
				 <td><input type="text" name="txtphy"></td>
			</tr>
			<tr>
			    <th>chemistry</th>
				 <td><input type="text" name="txtchem"></td>
			</tr>
			<tr>
			    <th>Mathematics</th>
				 <td><input type="text" name="txtmaths"></td>
			</tr>
			<tr>
			    <th>English</th>
				 <td><input type="text" name="txteng"></td>
			</tr>
			<tr>
			    <th>Urdu</th>
				 <td><input type="text" name="txturdu"></td>
			</tr>
			<tr>
			    <th>Computer</th>
				 <td><input type="text" name="txtcomputer"></td>
			</tr>
			<tr>
			    <th></th>
				 <td><input type="Submit" value="Calculate"></td>
			</tr>
	   </table>
	      
	</form>
	</center>
</html>

<?php
 echo "<table border='2'>";
  $name=$_POST['txtname'];
   $fname=$_POST['txtfname'];
    $roll=$_POST['txtroll'];
      $phy=$_POST['txtphy'];
	    $chem=$_POST['txtchem'];
		  $maths=$_POST['txtmaths'];
		    $eng=$_POST['txteng'];
			  $urdu=$_POST['txturdu'];
			    $computer=$_POST['txtcomputer'];
				echo "<tr><th colspan='2'><center>Personal Information</center></th></tr>"."</br>";
	echo "<tr><th>Your Name is : </th>" . "<td>$name</td></tr>" . "<br>";
		echo "<tr><th>Your Father-Name is :</th> " . "<td>$fname</td></tr> ". "<br>";
			echo "<tr><th>Your Roll-No is :</th> " . "<td>$roll</td></tr>". "<br>";
			echo "<tr><th colspan='2'><center>Sujects</center></th></tr>"."</br>";
			echo "<tr><th>Your Physics Marks are :</th>  " . "<td>$phy</td></tr>" . "<br>";
			echo "<tr><th>Your Chemistry Marks are :</th>  " . "<td>$chem</td></tr>". "<br>";
			echo "<tr><th>Your Mathematics Marks are :</th>  " . "<td>$maths</td></tr>" . "<br>";
			echo "<tr><th>Your English Marks are :</th>  " . "<td>$eng</td></tr>" . "<br>";
			echo "<tr><th>Your Urdu Marks are : </th> " . "<td>$urdu</td></tr>" . "<br>";
			echo "<tr><th>Your Computer Marks are :</th>  " . "<td>$computer</td></tr>" . "<br>";
			
			  $tm=600;
			  $obm=$phy+$chem+$maths+$eng+$urdu+$computer;
			  $per=$obm/$tm*100;
			echo "<tr><th colspan='2'><center>Perfomance</center></th></tr>"."</br>";  
			echo "<tr><th>Your Total Marks are :</th> "."<td>$tm</td></tr>"."</br>";
			echo "<tr><th>Your Obtained Marks are : </th>" ."<td>$obm</td></tr>"."</br>";
			echo "<tr><th>Your Percentage is : </th> "."<td>$tm</td></tr>"."</br>";
			if($per>80 && $per<70)
			{
				echo "<tr><th>Your Grade is</th><td> A1</td></tr>";
			}
			if($per>70 && $per<60)
			{
				echo "<tr><th>Your Grade is</th><td> A</td></tr>";
			}
			if($per>60 && $per>50)
			{
				echo "<tr><th>Your Grade is</th><td> B</td></tr>";
			}if($per<50 && $per>40)
			{
				echo "<tr><th>Your Grade is</th><td> C</td></tr>";
			}
		    else
			{
				echo "<tr><th>You are fail</th><td>Sorry !</td></tr>";
			}
  echo "</table>";
?>