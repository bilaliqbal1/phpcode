<html>
<form method="post">
<input type="id" name="txtid" placeholder="Id"/></br>
<input type="age" name="txtage" placeholder="Password"/></br>
<input type="address" name="txtaddress" placeholder="Address"/></br>
<input type="fee" name="txtfee" placeholder="fee"/></br>
<input type="submit" name="btn" value="Submit"/>
<input type="submit" name="btn_update" value="Update"/>
<input type="submit" name="btn_deleted" value="Deleted"/></br>

</form>

<table border="2">
	<tr>
		<th>Id </th>
		<th>Age </th>
		<th>Fees </th>
		<th>Address </th>
	</tr>
</html>
<?php
if(isset($_POST['btn']))	

{
$id="";
$age=$_POST['txtage'];
$address=$_POST['txtaddress'];
$fee=$_POST['txtfee'];
$conn=mysqli_connect("localhost","root","","k.k");

$insert= mysqli_query($conn,"insert into khubi_table values('".$id."','".$age."','".$fee."','".$address."');");
if($insert)
{
	echo "Data Inserted";
}
else
{
	echo "Data isn't Inserted";
}	
}

else if(isset($_POST['btn_update']))	

{
$id=$_POST['txtid'];
$age=$_POST['txtage'];
$address=$_POST['txtaddress'];
$fee=$_POST['txtfee'];
$conn=mysqli_connect("localhost","root","","k.k");

$insert= mysqli_query($conn,"update khubi_table set Age='".$age."', fee='".$fee."', address='".$address."' where id='".$id."'");
if($insert)
{
	echo "Data Updated";
}
else
{
	echo "Data isn't Inserted";
}	
}
else  if(isset($_POST['btn_deleted']))	

{
$id=$_POST['txtid'];

$conn=mysqli_connect("localhost","root","","k.k");

$insert= mysqli_query($conn,"Delete from khubi_table where id='".$id."'");
if($insert)
{
	echo "Data Deleted";
}
else
{
	echo "Data isn't Inserted";
}	
}


$conn=mysqli_connect("localhost","root","","k.k");
$select=mysqli_query($conn,"Select * from khubi_table");
$num=mysqli_num_rows($select);
for($i=0; $i<$num; $i++)
{
	$row=mysqli_fetch_array($select);
	echo "<tr>";
			echo "<td>" . $row[0] . "</td>";
			echo "<td>" . $row[1] . "</td>";
			echo "<td>" . $row[2] . "</td>";
			echo "<td>" . $row[3] . "</td>";
	echo "</tr>";
	
}
?>
