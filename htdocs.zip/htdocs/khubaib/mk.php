<?php
/**
 $fact = 4;
 $rst = 1;
 for($i=$fact; $i>=1; $i--)
 {
	 $rst = $rst*$i;
	 echo $i."*"; 	
 }	 
  echo "=" . $rst;
**/
 /**
 $i=0;
 while($i<=10)
 {
	 echo $i;
	 $i++;
 }
 **/
 
 $i=0;
 while($i<=20)
 {
	 echo "odd :" .$i ."<br>";
	 $i+=2;
 }
 $i=1;
 while($i<=20)
 {
	 echo "even:". $i ."<br>";
	 $i+=2;
 }
 $a=1;
 while($a<=10)
 {
	 echo "2*" .$a . "=" . $a*2 . "<br>";
     $a++;	 
 }
 
 
 

  $power=6;
$base=4;
$rst=1;
$i=1;
while($i<=$power)
{
	$rst = $rst * $base;
	echo $base . "*";
	$i++;
}
  echo " = " .$rst;
  
  $fact = 9;
  $rst = 1;
  $i = 1;
  
  while($i<=$fact)
  {
	  $rst =$rst*$i;
	  echo $i. "*";	
      $i++;	  
  }
  echo "=" .$rst;














?>