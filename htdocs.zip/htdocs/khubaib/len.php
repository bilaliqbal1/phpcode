<html>
	<form method="post">
		<table border="1">
			<tr>
				<th> Name : </th>
				<td><input type="text" name="txtname" />
			</tr>
			
			<tr>
				<th> Email : </th>
				<td><input type="email" name="txtemail" />
			</tr>
			<tr>
				<th> Password : </th>
				<td><input type="password" name="txtpass" placeholder="Min 4 to 8 Characters" />
			</tr>
			<tr>
				<th> Confirm Password : </th>
				<td><input type="password" name="txtcpass" />
			</tr>
			<tr>
				<th>   </th>
				<td><input type="submit" name="btn_click" value="check password" />
			</tr>
		</table>
	
	</form>
</html>
<?php

if(isset($_POST['btn_click']))
{
	$name=$_POST['txtname'];
	$email=$_POST['txtemail'];
	 $pass=$_POST['txtpass'];
	$cpass=$_POST['txtcpass'];
	
	if($pass == $cpass)
	{
		if(strlen($pass) >3 && strlen($pass) < 9)
		{
			echo "<table border='1'>";
				echo "<tr>";
					echo "<th> Name </th>";
					echo "<th> Email </th>";
					echo "<th> Password </th>";
				echo "</tr>";
				echo "<tr>";
					echo "<th> $name </th>";
					echo "<th> $email </th>";
					echo "<th>";
					for($i=0; $i<strlen($pass); $i++)
					{
						echo "*";
					}
					echo "</th>";
				echo "</tr>";
			echo "</table>";
		}
		else
		{
				echo "Please Enter Min 4 to Max 8";
		}
	
	}
	else
	{
		echo "Password did not match";
	}
}

?>