<?php
$server="localhost";
$username="root";
$password="";
$database="insert_tb";
$conn=mysqli_connect($server,$username,$password);
$insert_db=mysqli_select_db($conn,$database);
if($conn)
{
	echo "server is connected";
}
else
{
	echo "server could not connected";
}	

















?>