<?php

/**
$i=1;
$j=1;
while($i<=5)
{
	while($j<=$i)
	{
		echo "*";
		$j++;
	}
	echo "<br>";
	$i++;
	$j=1;
}

$k=5;
while($k>=0)
{
	$l=1;
	while($l<=$k)
	{
		echo "*";
		$l++;
	}
	echo "<br>";
	$k--;
	
}
**/
$power=4;
$base=3;
$rst=1;
$i=1;
while($i<=$power)
{
	$rst = $rst * $base;
	echo $base . "*";
	$i++;
}
  echo " = " .$rst;
?>