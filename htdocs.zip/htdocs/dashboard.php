<?php

$conn=mysqli_connect("localhost","root","","Login_panel");
session_start();
isset($_SESSION['emial']) or die(header("location:faii.php"));
$email=$_SESSION['emial'];
$insert=mysqli_query($conn,"select * from info where Email='".$email."'");
$row=mysqli_fetch_array($insert);
$len=strlen($row[3]);
echo "Welcome to Mr." . $row[1];
echo "<br>";
echo "Father Name is ." . $row[4];
echo "<br>";
echo "Age is." . $row[5];
echo "<br>";
echo "Contact is ." . $row[6];
echo "<br>";
echo "Email is ." . $row[2];
echo "<br>";
echo "Password is .";
for($i=1; $i<=$len; $i++){echo  "*";}
?>