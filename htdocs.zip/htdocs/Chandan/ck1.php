<html>
<form method="post">

<input type="name" name="txtname" placeholder="Name"/></br>
<input type="email" name="txtemail" placeholder="Email"/></br>
<input type="password" name="txtpass" placeholder="Password"/></br>
<input type="password" name="txtcpass" placeholder="Confirm Password"/></br>
<input type="submit" name="btn" value="Submit"/></br>

</form>
</html>
<?php
if(isset($_POST['btn']))	

$name=$_POST['txtname'];
$email=$_POST['txtemail'];
$pass=$_POST['txtpass'];
$cpass=$_POST['txtcpass'];

if($name=="Chandan Kumar" && $pass==$pass && $cpass==$pass)
{
	echo "<script> alert('Log in Successfully! Welcome $name')</script>";
}
else if ($name=="Chandan Kumar" && $pass!=$pass && $cpass==$pass) 
{
	echo "<script> alert('Invalid Password')</script>";
	
} 
else if($name!="Chandan Kumar" && $pass=$pass && $cpass==$pass)
{
echo "<script> alert('Invalid Username')</script>";
}
else if ($name=="Chandan Kumar" && $pass==$pass && $cpass!=$pass) 
{
	echo "<script> alert('Password Mismatched')</script>";
}
?>
