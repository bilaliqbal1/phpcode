<html>
<form method="post">

<input type="id" name="txtid" placeholder="Id"/></br>
<input type="name" name="txtname" placeholder="Name"/></br>
<input type="email" name="txtemail" placeholder="Email"/></br>
<input type="password" name="txtpass" placeholder="Password"/></br>
<input type="phone" name="txtphone" placeholder="Phone"/></br>
<input type="submit" name="btn" value="Submit"/>
<input type="submit" name="btn_update" value="Update"/>
<input type="submit" name="btn_deleted" value="Deleted"/></br>

</form>
</html>
<?php
if(isset($_POST['btn']))	

{
$id="";
$name=$_POST['txtname'];
$email=$_POST['txtemail'];
$password=$_POST['txtpass'];
$phone=$_POST['txtphone'];
$conn=mysqli_connect("localhost","root","","insert");

$insert= mysqli_query($conn,"insert into khubi_table values('".$id."','".$Age."','".$address."','".fee."');");
if($insert)
{
	echo "Data Inserted";
}
else
{
	echo "Data isn't Inserted";
}	
}

else if(isset($_POST['btn_update']))	

{
$id=$_POST['txtid'];
$name=$_POST['txtname'];
$email=$_POST['txtemail'];
$password=$_POST['txtpass'];
$phone=$_POST['txtphone'];
$conn=mysqli_connect("localhost","root","","insert");

$insert= mysqli_query($conn,"update insert_tb set Name='".$name."', Email='".$email."', Password='".$password."', phone='".$phone."' where id='".$id."'");
if($insert)
{
	echo "Data Updated";
}
else
{
	echo "Data isn't Inserted";
}	
}
else  if(isset($_POST['btn_deleted']))	

{
$id=$_POST['txtid'];

$conn=mysqli_connect("localhost","root","","insert");

$insert= mysqli_query($conn,"Delete from insert_tb where id='".$id."'");
if($insert)
{
	echo "Data Deleted";
}
else
{
	echo "Data isn't Inserted";
}	
}
?>
