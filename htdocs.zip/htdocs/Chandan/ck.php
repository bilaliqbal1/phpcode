<?php 
	
	$base = 5;
	
	$rst=1;
	for($i=$base; $i>=1; $i--)
	{
		$rst=$rst*$i;
		echo $i." * ";
	}
	echo $rst;
	
	for($i=$base; $i>=1; $i--)
	{
		for($j=1; $j<=2; $j++)
		{
			echo $i*$j."<br>";
		}
	}
?>