<html>
	<center>
		<table border="1">
			<form method="POST">

				<h1>Registration Form</h1>
				
							<tr>
				<th>Id</th>
				<td><input type="number" name="id"/></td>
			</tr>
				
			<tr>
				<th>Name</th>
				<td><input type="text" name="name"/></td>
			</tr>
			
						<tr>
				<th>Father Name</th>
				<td><input type="text" name="fname"/></td>
			</tr>
			
						<tr>
				<th>Age</th>
				<td><input type="number" name="age"/></td>
			</tr>
			
			
						<tr>
				<th>Contact</th>
				<td><input type="number" name="con"/></td>
			</tr>
			
			
				<tr>
				<th>Email</th>
				<td><input type="text" name="email"/></td>
			</tr>
			
					<tr>
				<th>Password</th>
				<td><input type="password" name="pass"/></td>
			</tr>
			
					<tr>
				<th> : </th>
				<td><input type="submit" name="btn1" value="submit"/></td>
			</tr>
		
		
	</form>

</table>
</html>

<?php

$conn=mysqli_connect("localhost","root","","Login_panel");
if(isset($_POST['btn1']))
{
	$id=$_POST['id'];
	$name=$_POST['name'];
	$email=$_POST['email'];
	$pass=$_POST['pass'];
	$fname=$_POST['fname'];
	$age=$_POST['age'];
	$contact=$_POST['con'];
	
	$select=mysqli_query($conn,"select * from info where email='$email'");
	$num=mysqli_num_rows($select);
	if($num > 0)
	{
		echo "<script> alert ('Email address is already exist');</script>";
	}
	else{
	$insert=mysqli_query($conn,"insert into info values('$id','$name','$email','$pass','$fname','$age','$contact');" );

	if($insert)
	{
		echo "<script> alert ('Data Save');</script>";
	}
	else
	{
		echo "<script> alert ('Invalid Data');</script>";
	}}
}
?>