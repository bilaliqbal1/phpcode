<?php
	class functions
	{
		function conn()
		{
			session_start();
			$conn=$_SESSION['conn']=mysqli_connect("localhost","root","","faizan");
		}
		function adddata($id,$name,$email,$password)
		{
			$conn=$_SESSION['conn'];
			$insert=mysqli_query($conn,"insert into ali values ('$id','$name','$email','$password')");
			if($insert)
			{
				echo "<script> alert('Data Save');</script>";
			}
			
			else
			{
				echo "<script> alert('Data Not Save');</script>";
			}
		}
		
		function showdata()
		{
			$conn=$_SESSION['conn'];
			$insert=mysqli_query($conn,"select * from ali");
			$num=mysqli_num_rows($insert);
			for($i=1; $i<=$num; $i++)
			{
				$row=mysqli_fetch_array($insert);
				echo "<tr>";
						echo "<td>" . $i . "</td>";
						echo "<td>" .$row[1] . "</td>";
						echo "<td>" . $row[2] . "</td>";
						echo "<td>" . $row[3] . "</td>";
				echo "</tr>";
			}
		}
	}
?>