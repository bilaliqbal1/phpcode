<html>
	<center>
		<table border="2">
			<form method="POST">

				<h1>Registration Form</h1>
				
							<tr>
				<th>Id</th>
				<td><input type="number" name="id"/></td>
			</tr>
				
			<tr>
				<th>Name</th>
				<td><input type="text" name="name"/></td>
			</tr>
			
				<tr>
				<th>Email</th>
				<td><input type="text" name="email"/></td>
			</tr>
			
					<tr>
				<th>Password</th>
				<td><input type="text" name="pass"/></td>
			</tr>
			
					<tr>
				<th> : </th>
				<td><input type="submit" name="btn" value="submit"/></td>
			</tr>
		
		
	</form>


</table>


		<table border="2">
			<form method="POST">

				<h1>Update Form</h1>
				
							<tr>
				<th>Id</th>
				<td><input type="number" name="id1"/></td>
			</tr>
				
			<tr>
				<th>Name</th>
				<td><input type="text" name="name1"/></td>
			</tr>
			
				<tr>
				<th>Email</th>
				<td><input type="text" name="email1"/></td>
			</tr>
			
					<tr>
				<th>Password</th>
				<td><input type="text" name="pass1"/></td>
			</tr>
			
					<tr>
				<th> : </th>
				<td><input type="submit" name="btn1" value="update"/></td>
			</tr>
		
		
	</form>


</table>

		<table border="2">
			<form method="POST">

				<h1>Delete Form</h1>
				
							<tr>
				<th>Id</th>
				<td><input type="number" name="id2"/></td>
			</tr>
				
			<tr>
				<th>Name</th>
				<td><input type="text" name="name2"/></td>
			</tr>
			
				<tr>
				<th>Email</th>
				<td><input type="text" name="email2"/></td>
			</tr>
			
					<tr>
				<th>Password</th>
				<td><input type="text" name="pass2"/></td>
			</tr>
			
					<tr>
				<th> : </th>
				<td><input type="submit" name="btn2" value="Delete"/></td>
			</tr>
		
		
	</form>

</table>
</html>


<?php

$conn=mysqli_connect("localhost","root","","panel");
if(isset($_POST['btn']))
{
	$id=$_POST['id'];
	$name=$_POST['name'];
	$email=$_POST['email'];
	$pass=$_POST['pass'];
	
	
	$insert=mysqli_query($conn,"insert into login values('$id','$name','$email','$pass');" );

	if($insert)
	{
		echo "<script> alert ('Data Save');</script>";
	}
}


if(isset($_POST['btn1']))
{
	$id1=$_POST['id1'];
	$name1=$_POST['name1'];
	$email1=$_POST['email1'];
	$pass1=$_POST['pass1'];
	
	
	$update=mysqli_query($conn,"update login set  Name='$name1',Email='$email1',Password='$pass1' where id='$id1'" );

	if($update)
	{
		echo "<script> alert ('Data Update');</script>";
	}
}


if(isset($_POST['btn2']))
{
	$id2=$_POST['id2'];
	$name2=$_POST['name2'];
	$email2=$_POST['email2'];
	$pass2=$_POST['pass2'];
	
	
	$delete=mysqli_query($conn,"delete from login where id='$id2'" );

	if($delete)
	{
		echo "<script> alert ('Data Delete');</script>";
	}
}




