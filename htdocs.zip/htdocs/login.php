<html>
	<center>
		<table border="2">
			<form method="POST">

				<h1>Login Form</h1>
			
				<tr>
				<th>Email</th>
				<td><input type="text" name="email"/></td>
			</tr>
			
					<tr>
				<th>Password</th>
				<td><input type="text" name="pass"/></td>
			</tr>
			
					<tr>
				<th> : </th>
				<td><input type="submit" name="btn" value="submit"/></td>
			</tr>
		
		
	</form>
</html>


<?php

$conn=mysqli_connect("localhost","root","","panel");
if(isset($_POST['btn']))
{
	$email=$_POST['email'];
	$pass=$_POST['pass'];
	
	
$insert=mysqli_query($conn,"select * from login where Email='".$email."' AND Password='$pass'");
$num=mysqli_num_rows($insert);

	if($num > 0)
	{
		$fetch=mysqli_fetch_array($insert);
		$name=$fetch[1n];
		echo "<script> alert ('Login Successfully Mr $name');</script>";
	}
	else
	{
		echo "<script> alert ('Invalid username or password');</script>";
	}
	
	
}

?>