 <html>
<form method="post">
	<table border="1">
		<tr>
			<th> Account No  : </th>
			<td> <input type="text" name="txtname" /></td>
		</tr>
		<tr>
			<th> Amount  : </th>
			<td> <input type="text" name="txtamt" /></td>
		</tr>
		<tr>
			<th> Transition Type  : </th>
			<td><select name="tran">
					<option value="0"> Debit </option>
					<option value="1"> Credit </option>
			</select>
			</td>
		</tr>
		<tr>
			<th>   : </th>
			<td> <input type="Submit" name="btn_reg" value="Add Transition" /></td>
			<td> <input type="submit" name="btn_search" value="search" /></td>
		</tr>
	</table>
	</form>
</html>

<?php

$conn=mysqli_connect("localhost","root","","mydb");
if(isset($_POST['btn_reg']))
{
	$id="";
	$name=$_POST['txtname'];
	$amt=$_POST['txtamt'];
	$tra=$_POST['tran'];
	
	$acnt=mysqli_query($conn,"Select * from accounts where id='".$name."'");
	$num=mysqli_num_rows($acnt);
	$fetch=mysqli_fetch_array($acnt);
	if($num> 0)
	{
			
						if($tra == 1)
						{
						$update=mysqli_query($conn,"update accounts set amount=amount+'".$amt."' where id='".$name."'");
						$insert=mysqli_query($conn,"insert into tran values('".$id."','".$name."','0','".$amt."');");
						}
						else
						{
							if($fetch[2] > $amt)
								{
						$update=mysqli_query($conn,"update accounts set amount=amount-'".$amt."' where id='".$name."'");
						$insert=mysqli_query($conn,"insert into tran values('".$id."','".$name."','".$amt."','0');");
								}
								else
								{
									echo "Your Amount is less then" . ($amt-$fetch[2]) ;
								}
						}
			
		
	}
	else
	{
		echo "Account Not Exist";
	}
	
	
	
	

	
	}
	if(isset($_POST['btn_search'])){
		$id=$_POST['txtname'];
		$select = mysqli_query($conn,"select * from tran where acount='".$id."'");
		$num = mysqli_num_rows($select);
		echo "<table border='1'>";
		echo "<tr>";
		echo "<th> id </th>";
		echo "<th> Debit </th>";
		echo "<th> Credit </th>";
		echo "</tr>";
		for($i=1; $i<=$num ; $i++){
			$row = mysqli_fetch_array($select);
			
			echo "<tr>";
			echo "<td>".$row[0] . "</td>";
			echo "<td>".$row[2] . "</td>";
			echo "<td>".$row[3] . "</td>";
			echo "</tr>";
		}
		
		
	}


?>