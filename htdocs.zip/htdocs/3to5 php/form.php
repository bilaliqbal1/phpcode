<html>
<body>
<form method="post">
   <input type="text" name="txt_name" placeholder="Enter your name"/></br>
   <input type="email" name="txt_email" placeholder="Enter your E-mail"/></br>
   <input type="password" name="txt_pass1" placeholder="Enter your Password"/></br>
   <input type="password" name="txt_pass2" placeholder="Confirm your Password"/></br>
   <input type="submit" name="btn_click" value="click me"/></br>
</form>
</center>
</body>
</html>
<?php
 if(isset($_post['btn_click']))
	 $name=$_post['txt_name'];
     $email=$_post['txt_email'];
     $pass=$_post['txt_pass1'];
	 $Cpass=$_post['txt_pass2'];
	 
	 if($email == "admin@admin.com" && $pass == "admin" && $Cpass == $pass)
	 {
		 echo "<script>alert('Login Successfully')</script>" ;
	 }
	 else 
	 {
		 echo "<script>alert('Invalid Password')</script>" ; 
	 }
?>