<?php
	$mat1 = array(1,2,3,4,5,6,7,8,9);
	$mat2 = array(1,2,3,4,5,6,7,8,9);
	$mat3 = 0;
	for($i=1;$i<=5;$i++){
		for($j=$i;$j<=$i;$j++){
			$mat3[$i][$j] = $mat1[$i][$j] + $mat2[$j][$j];
			echo  $mat3[$i][$j];
		}
		
		echo "<br>";
	}
?>