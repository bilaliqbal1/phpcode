<?php
	$name = "Muhammad bilal";
	$fname = "Muhammad Iqbal";
	/**$age = 29;
	$month = $age*12;
	$week = $month*4;
	$day = $week*7;
	$hr = $day * 24;
	$min = $hr * 60;
	$sec = $min * 60;
     echo "<center><h2 background-color:'red'>Age Calculator:</h2>
	Name : $name <br> Fathername : $fname <br> Age : $age <br> Age in month : $month
	 <br> Age in Week : $week <br> Age in day : $day <br> Age in Hour: $hr <br> Age in Minutes : $min
	 <br> Age in Seconds : $sec
 	</center>";
	**/
	$tm = 500;
	$om = 60+70+80+90+50;
	$per = ($om*100)/500;
	echo "<h1 align='center' style='background-color:black; font-size:55px; color:white'> Marksheet</h1>
	<h2> Personal Information:</h2> Name: $name <br> Father's name: $fname <br> Class: 10th 
	<br> Rollno: 123 <br> <h2> Subjects name : </h2> Mathematics: 60 <br> Physics: 70 <br> Chemistry: 50
	<br> Computer: 90 <br> Islamiat: 80 <br> <h2> Result: </h2> Total marks = $tm
	<br> Obtained marks: $om <br> Percentage is $per<br>";
	if($per>=80 && $per<=100){
		echo "Your grade is A+";
	}
	if($per>=70 && $per<=80 ){
		echo "Your grade is A";
	}
	if($per>=60 && $per<70){
		echo "Your grade is B";
	}
	if($per>=50 && $per<60){
		echo "Your grade is C";
	}
	if($per>=40 && $per<50){
		echo "Your grade is D";
	}
	if($per<40){
		echo "You are fail";
	}
?>