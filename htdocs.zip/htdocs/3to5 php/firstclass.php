<?php
	
	echo "<center><h2 style='color:blue;'>C.V(curriculum vitae)</h2><img src='image.gif'/> <h4>Muhammad Bilal Muhammad Iqbal <br> 75 Lea market <br> Telephone:0323222222 <br> Email: bilaliqbal@email.com </h4> </center>";
	echo " <h2> Objectives: </h2> <p> For the position of entry level executive</p>" ;
	echo "<h2> Summary Of Skills: </h2> <p> I have done my intermediate in p.e.c.h.s oollege in science and I am undergraduate in lyari university.</p><p> I have done my intermediate in p.e.c.h.s oollege in science and I am undergraduate in lyari university.</p><p> I have done my intermediate in p.e.c.h.s oollege in science and I am undergraduate in lyari university.</p>  ";
	echo "<h2> Key Strength: </h2> <p><ul><li> Market research </li><li> Market research </li><li> Market research </li></ul><br></p> ";
	echo "<h2> Qualification: </h2> <p> Inter in science 2017 </p> ";


?>
