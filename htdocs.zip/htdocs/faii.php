<html>
	<center>
		<table border="1">
			<form method="POST" >

				<h1>Login Form</h1>
			
				<tr>
				<th>Email</th>
				<td><input type="text" name="email"/></td>
			</tr>
			
					<tr>
				<th>Password</th>
				<td><input type="text" name="pass"/></td>
			</tr>
			
					<tr>
				<th> : </th>
				<td><input type="submit" name="btn" value="submit"/></td>
			</tr>
		
		
	</form>
</html>

<?php

$conn=mysqli_connect("localhost","root","","Login_panel");
if(isset($_POST['btn']))
{
	$email=$_POST['email'];
	$pass=$_POST['pass'];
	
	
$insert=mysqli_query($conn,"select * from info where Email='".$email."' AND Password='$pass'");
$num=mysqli_num_rows($insert);
	session_start();
	if($num > 0)
	{
		
	$_SESSION['emial']=$email;
	$_SESSION['pass']=$password;
header("location:dashboard.php");	
	}
	else
	{
		echo "<script> alert ('Invalid username or password');</script>";
	}
	
	
}




?>


